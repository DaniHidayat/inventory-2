<?php 

header("Content-type: application/octet-stream");

header("Content-Disposition: attachment; filename=$title.xls");

header("Pragma: no-cache");

header("Expires: 0");

?>

<table border="1" width="100%">

<thead>

<tr>

 <th>Kode Barang</th>

 <th>Nama Barang</th>

 <th>Harga Jual</th>

 <th>Stok</th>
 </tr>

</thead>

<tbody>

<?php $i=1; foreach($user as $user) { ?>

<tr>

 <td><?php echo $user->barang_id ?></td>

 <td><?php echo $user->barang_nama ?></td>

 <td><?php echo $user->barang_harjul ?></td>

<td><?php echo $user->barang_stok ?></td>

 </tr>

<?php $i++; } ?>

</tbody>

</table>