<header class="main-header">

    <!-- Logo -->
    <a href="<?php echo site_url('welcome') ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini">INV</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">INVENTORY</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
        
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
             <?php
              $id_admin=$this->session->userdata('idadmin');
              $q=$this->db->query("SELECT * FROM tbl_user WHERE user_id='$id_admin'");
              $c=$q->row_array();
          ?>
<!--  -->
      <li class="dropdown user user-menu">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <img src="<?php echo base_url('assets/images/user.png') ?>" class="user-image" alt="">
        <span class="hidden-xs"><?php echo $c['user_nama'];?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo base_url('assets/images/user.png') ?>" class="img-circle" alt="">
                    <p>
                  <?php echo $c['user_nama'];?>
                  <?php if($c['user_level']=='1'):?>
                    <small>Administrator</small>
                  <?php elseif($c['user_level']=='2'):?>
                    <small>Kasir</small>
                    <?php else:?>
                      <small>Owner</small>
                  <?php endif;?>
                </p>

              </li>
              <!-- Menu Body -->

              <!-- Menu Footer-->
              <li class="user-footer">
                              <div class="pull-right">
                 <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-sign-out"></span> Logout</a>
                </div>
                
                              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        </ul>
      </div>

    </nav>
  </header>
  <!--Modal Add Pengguna-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Logout</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'Login/logout'?>" method="post" enctype="multipart/form-data">
                    

                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-6 control-label">Apakah yakin ingin keluar?</label>
                                       
                                    </div>

                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-flat" data-dismiss="modal"><span class="fa fa-times"></span></button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan"><span class="fa fa-check"></span></button>
                    </div>
                    </form>
                </div>
            </div>
        </div>