
<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">GENERAL</li>
            <?php $h=$this->session->userdata('akses'); ?>
                    <?php $u=$this->session->userdata('user'); ?>
                    <?php if($h=='1'){ ?> 



        <li><a href="<?php echo base_url('admin/grafik/dashboard')?>"onclick="loadPage"><i class="fa fa-dashboard text-aqua"></i> <span>DASHBOARD</span></a></li> 
        
        <li>
          <a href="<?php echo base_url().'admin/penjualan'?>" >
            <i class="fa fa-shopping-cart"></i> <span>Barang Keluar</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
         <li>
          <a href="<?php echo base_url().'admin/pembelian'?>">
            <i class="fa fa-shopping-cart"></i> <span>Barang Masuk</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
        
         <li>
          <a href="<?php echo base_url().'admin/grafik'?>">
            <i class="fa fa-line-chart"></i> <span>Grafik</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
       
         <li>
          <a href="<?php echo base_url().'admin/laporan'?>">
            <i class="fa fa-file"></i> <span>Laporan</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>

         <li>
          <a href="<?php echo base_url().'admin/barang'?>">
            <i class="fa fa-cubes"></i> <span>Barang</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
        
         <li>
          <a href="<?php echo base_url().'admin/kategori'?>">
            <i class="fa fa-sitemap"></i> <span>Kategori</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>

         <li>
          <a href="<?php echo base_url().'admin/satuan'?>">
            <i class="fa fa-sitemap"></i> <span>Satuan</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>

         <li>
          <a href="<?php echo base_url().'admin/suplier'?>">
            <i class="fa fa-truck"></i> <span>Suplier</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
         <li>
          <a href="<?php echo base_url().'admin/pengguna'?>">
            <i class="fa fa-users"></i> <span>Pengguna</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>


      

        <?php }?>
          <?php if($h=='2'){ ?>
        
     <li class="treeview">
          <a href="#">
            <i class="fa fa-shopping-cart"></i>
            <span>Transaksi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url().'admin/penjualan'?>"><i class="fa fa-shopping-cart"></i> Transaksi Eceran</a></li>
            <li><a href="<?php echo base_url().'admin/penjualan_grosir'?>"><i class="fa fa-shopping-cart"></i>Transaksi Grosir</a></li>
            
          </ul>
        </li>
        
        
        <?php }?>
         <?php if($h=='3'){ ?> 
                      <!--dropdown-->
                   <li>
          <a href="<?php echo base_url().'admin/suplier'?>">
            <i class="fa fa-truck"></i> <span>Suplier</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
       <li>
          <a href="<?php echo base_url().'admin/kategori'?>">
            <i class="fa fa-sitemap"></i> <span>Kategori</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
         <li>
          <a href="<?php echo base_url().'admin/barang'?>">
            <i class="fa fa-shopping-cart"></i> <span>Barang</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>
         <li>
          <a href="<?php echo base_url().'admin/pembelian'?>">
            <i class="fa fa-shopping-cart"></i> <span>Pembelian</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green"></small>
            </span>
          </a>
        </li>

                    <?php }?>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>