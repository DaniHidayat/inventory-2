<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	Selamat, captcha yang anda masukan sudah benar :)
</body>
</html>