<?php
class M_satuan extends CI_Model{

	function hapus_satuan($kode){
		$hsl=$this->db->query("DELETE FROM tbl_satuan where id_satuan='$kode'");
		return $hsl;
	}

	function update_satuan($kode,$sat){
		$hsl=$this->db->query("UPDATE tbl_satuan set nama_satuan='$sat' where id_satuan='$kode'");
		return $hsl;
	}

	function tampil_satuan(){
		$hsl=$this->db->query("select * from tbl_satuan order by nama_satuan ASC");
		return $hsl;
	}

	function simpan_satuan($sat){
		$hsl=$this->db->query("INSERT INTO tbl_satuan(nama_satuan) VALUES ('$sat')");
		return $hsl;
	}

}