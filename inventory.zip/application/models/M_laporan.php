<?php
class M_laporan extends CI_Model{
	function get_stok_barang(){
		$hsl=$this->db->query("SELECT kategori_id,kategori_nama,barang_nama,barang_stok FROM tbl_kategori JOIN tbl_barang ON kategori_id=barang_kategori_id GROUP BY kategori_id,barang_nama");
		return $hsl;
	}
	function get_data_barang(){
		$hsl=$this->db->query("SELECT kategori_id,barang_id,kategori_nama,barang_nama,barang_satuan,barang_harjul,barang_stok FROM tbl_kategori JOIN tbl_barang ON kategori_id=barang_kategori_id GROUP BY kategori_id,barang_nama");
		return $hsl;
	}
	function get_bulan_jual(){
		$hsl=$this->db->query("SELECT DISTINCT  DATE_FORMAT(jual_tanggal,'%M %Y') AS bulan FROM tbl_jual");
		return $hsl;
	}
	function get_tahun_jual(){
		$hsl=$this->db->query("SELECT DISTINCT YEAR(jual_tanggal) AS tahun FROM tbl_jual");
		return $hsl;
	}

	function get_data_barang_keluar(){
		$hsl=$this->db->query("SELECT a.*,b.*,c.* FROM tbl_jual a JOIN tbl_detail_jual b ON a.jual_nofak= b.d_jual_nofak JOIN tbl_satuan c ON b.d_jual_barang_satuan=c.id_satuan ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_data_barang_masuk(){
	$hsl=$this->db->query("SELECT a.*,b.*,c.*  FROM tbl_beli a JOIN  tbl_detail_beli b ON a.beli_nofak=b.d_beli_nofak JOIN tbl_suplier c ON a.beli_suplier_id=c.suplier_id ORDER BY beli_nofak DESC");
		return $hsl;
	}
	function get_total_penjualan(){
		$hsl=$this->db->query("SELECT  jual_nofak,DATE_FORMAT(jual_tanggal,'%d %M %Y') AS jual_tanggal,jual_total,d_jual_barang_id,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harpok,d_jual_barang_harjul,d_jual_qty,d_jual_diskon,SUM(d_jual_total) as total FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak ORDER BY jual_nofak DESC");
		return $hsl;
	}
	function get_total_pembelian(){
		$hsl=$this->db->query("SELECT  SUM(d_beli_total) as total FROM tbl_detail_beli JOIN tbl_beli ON d_beli_nofak=beli_nofak ORDER BY beli_nofak DESC");
		return $hsl;
	}
	
}