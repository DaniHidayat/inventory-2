<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
public function __construct()
{
	parent::__construct();
	if ($this->session->userdata('masuk')!=TRUE){
		$url=base_url();
		redirect($url);
		
	};
	$this->load->model('m_kategori');
	$this->load->model('m_barang');
	$this->load->model('m_suplier');
	$this->load->model('m_pembelian');
	$this->load->model('m_penjualan');
	$this->load->model('m_laporan');
}
	public function index()
	{
		$data['data']=$this->m_barang->tampil_barang();
		$data['kat']=$this->m_kategori->tampil_kategori();
		$this->load->view('admin/v_laporan', $data);	
	}
	function lap_stok_barang(){
		$x['data']=$this->m_laporan->get_stok_barang();
		$this->load->view('admin/laporan/v_lap_stok_barang', $x);
	}
	function lap_data_barang(){
		$x['data']=$this->m_laporan->get_data_barang();
		$this->load->view('admin/laporan/v_lap_barang', $x);
	}
	public function export_excel(){
 					$data = array( 'title' => 'Laporan Excel',
 					'user' => $this->m_barang->listing());
 				$this->load->view('admin/laporan/lap_excel_barang',$data);
 }

 	function lap_data_barang_keluar(){
 		$x['data']=$this->m_laporan->get_data_barang_keluar();
 		$x['jml']=$this->m_laporan->get_total_penjualan();
 		$this->load->view('admin/laporan/v_lap_barang_keluar', $x);
 		
 	} 
 	function lap_data_barang_masuk(){
 		$x['data']=$this->m_laporan->get_data_barang_masuk();
 		$x['jml']=$this->m_laporan->get_total_pembelian();
 		$this->load->view('admin/laporan/v_lap_barang_masuk',$x);
 	}
}

/* End of file Laporan.php */
/* Location: ./application/controllers/admin/Laporan.php */