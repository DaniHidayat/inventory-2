<?php
class Satuan extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url();
            redirect($url);
        };
		$this->load->model('M_satuan');
	}
	function index(){
	if($this->session->userdata('akses')){
		$data['data']=$this->M_satuan->tampil_satuan();
		$this->load->view('admin/v_satuan',$data);
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
	function tambah_satuan(){
	if($this->session->userdata('akses')){
		$sat=$this->input->post('satuan');
		$this->M_satuan->simpan_satuan($sat);
		$this->session->set_flashdata('msg', 'success');
		redirect('admin/satuan');
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
	function edit_satuan(){
	if($this->session->userdata('akses')){
		$kode=$this->input->post('kode');
		$sat=$this->input->post('satuan');
		$this->M_satuan->update_satuan($kode,$sat);
		redirect('admin/satuan');
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
	function hapus_satuan(){
	if($this->session->userdata('akses')){
		$kode=$this->input->post('kode');
		$this->M_satuan->hapus_satuan($kode);
		redirect('admin/satuan');
	}else{
        echo "Halaman tidak ditemukan";
    }
	}
}